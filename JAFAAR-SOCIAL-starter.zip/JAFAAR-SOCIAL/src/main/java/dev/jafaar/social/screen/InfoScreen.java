package dev.jafaar.social.screen;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public final class InfoScreen extends Screen {
    private final Screen parent;
    private final String heading;
    private final String message;

    public InfoScreen(Screen parent, String heading, String message) {
        super(Component.literal(heading));
        this.parent = parent;
        this.heading = heading;
        this.message = message;
    }

    @Override
    protected void init() {
        this.addRenderableWidget(Button.builder(Component.literal("Back"),
                button -> this.minecraft.setScreen(parent))
                .bounds(this.width / 2 - 100, this.height / 2 + 30, 200, 20)
                .build());
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(graphics, mouseX, mouseY, partialTick);
        graphics.drawCenteredString(this.font, heading, this.width / 2,
                this.height / 2 - 30, 0xE5C76B);
        graphics.drawCenteredString(this.font, message, this.width / 2,
                this.height / 2 - 5, 0xFFFFFF);
        super.render(graphics, mouseX, mouseY, partialTick);
    }
}
