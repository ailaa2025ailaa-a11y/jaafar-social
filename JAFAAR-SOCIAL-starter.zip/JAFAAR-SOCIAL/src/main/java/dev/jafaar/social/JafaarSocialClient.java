package dev.jafaar.social;

import net.fabricmc.api.ClientModInitializer;

public final class JafaarSocialClient implements ClientModInitializer {
    public static final String MOD_ID = "jafaar_social";

    @Override
    public void onInitializeClient() {
        System.out.println("[JAFAAR SOCIAL] Client initialized.");
    }
}
