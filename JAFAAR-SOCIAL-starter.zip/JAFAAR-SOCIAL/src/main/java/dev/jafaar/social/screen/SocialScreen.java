package dev.jafaar.social.screen;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/**
 * First UI shell. Online accounts, friends sync and chat transport are added
 * in later milestones; this screen intentionally does not pretend those
 * services are already connected.
 */
public final class SocialScreen extends Screen {
    private final Screen parent;

    public SocialScreen(Screen parent) {
        super(Component.literal("JAFAAR SOCIAL"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int center = this.width / 2;
        int top = this.height / 2 - 58;

        this.addRenderableWidget(Button.builder(
                Component.literal("Friends"),
                button -> this.minecraft.setScreen(new InfoScreen(this,
                        "FRIENDS",
                        "Friend requests and online status will be added here."))
        ).bounds(center - 100, top, 200, 20).build());

        this.addRenderableWidget(Button.builder(
                Component.literal("Host World"),
                button -> this.minecraft.setScreen(new InfoScreen(this,
                        "HOST WORLD",
                        "LAN hosting and Internet relay setup will be added here."))
        ).bounds(center - 100, top + 26, 200, 20).build());

        this.addRenderableWidget(Button.builder(
                Component.literal("Social Chat"),
                button -> this.minecraft.setScreen(new InfoScreen(this,
                        "SOCIAL CHAT",
                        "Private and group chat will be added here."))
        ).bounds(center - 100, top + 52, 200, 20).build());

        this.addRenderableWidget(Button.builder(
                Component.literal("Back"),
                button -> this.minecraft.setScreen(parent)
        ).bounds(center - 100, top + 88, 200, 20).build());
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(graphics, mouseX, mouseY, partialTick);
        graphics.drawCenteredString(this.font, "JAFAAR SOCIAL", this.width / 2,
                this.height / 2 - 92, 0xE5C76B);
        super.render(graphics, mouseX, mouseY, partialTick);
    }
}
