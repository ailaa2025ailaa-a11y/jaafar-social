package dev.jafaar.social.mixin;

import dev.jafaar.social.screen.SocialScreen;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.components.Renderable;
import net.minecraft.client.gui.narration.NarratableEntry;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(TitleScreen.class)
public abstract class TitleScreenMixin {
    @Shadow
    protected abstract <T extends GuiEventListener & Renderable & NarratableEntry> T addRenderableWidget(T widget);

    @Inject(method = "init", at = @At("TAIL"))
    private void jafaarSocial$addSocialButton(CallbackInfo ci) {
        Screen screen = (Screen) (Object) this;
        this.addRenderableWidget(Button.builder(Component.literal("JAFAAR SOCIAL"),
                button -> screen.getMinecraft().setScreen(new SocialScreen(screen)))
                .bounds(screen.width / 2 - 100, screen.height / 4 + 108, 200, 20)
                .build());
    }
}
