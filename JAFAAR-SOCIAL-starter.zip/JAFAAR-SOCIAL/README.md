# JAFAAR SOCIAL

A client-side Fabric mod project for Minecraft Java 26.1.x.

## Current milestone

- Adds a JAFAAR SOCIAL button to the title screen.
- Adds a JAFAAR SOCIAL button to the pause menu.
- Opens a first-pass social hub with Friends, Host World and Social Chat entries.
- The feature pages are UI placeholders only; online accounts, friend synchronization,
  chat transport and Internet relay hosting are not implemented yet.

## Build

Requirements:
- JDK 25
- Gradle 9.4.0

Run:

```bash
gradle build
```

The JAR will be in `build/libs/`.

## GitHub Actions

Push this project to a GitHub repository. The workflow at
`.github/workflows/build.yml` builds the mod and uploads the JAR as an Actions artifact.

## Version note

This starter is pinned to Minecraft 26.1.2, Fabric Loader 0.19.5 and Loom 1.18.2.
Minecraft 26.1 introduced major mod-development changes and requires Java 25.
If your launcher profile is specifically 26.1 (not 26.1.2), update the pinned game
and loader versions to the exact versions installed in that profile before building.
